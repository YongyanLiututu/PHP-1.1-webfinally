<?php

$carsData = file_get_contents('cars1.json');
$cars = json_decode($carsData, true);

foreach ($cars['cars'] as &$car) {
    if ($car['id'] === "1") {
        $car['availability'] = false;
        break;
    }
}

echo json_encode($cars, JSON_PRETTY_PRINT);


?>